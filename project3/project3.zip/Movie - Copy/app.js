const express = require("express");
const path = require("path");
const app = express();
const port = 80;


//EXPRESS SPECIFIC STUFF
app.use('/static', express.static('static'))//For service static file
app.use(express.urlencoded())

//PUB SEPCIFIC STUFF
app.set('view engine', 'pug')//set the templet engine as pug
app.set('views', path.join(__dirname, 'views'))  //set view directory

//END POINTS
app.get('/',(req, res)=>{
    const params = { }
    res.status(200).render('home.pug',params);
})

app.get('/contact',(req, res)=>{
    const params = { }
    res.status(200).render('contact.pug',params);
})

app.get('/about',(req, res)=>{
    const params = { }
    res.status(200).render('about.pug',params);
})

app.get('/info',(req, res)=>{
    const params = { }
    res.status(200).render('info.pug',params);
})

app.get('/service',(req, res)=>{
    const params = { }
    res.status(200).render('service.pug',params);
})

//START THE SERVER
app.listen(port, ()=>{
    console.log(`the application successfully on port ${port}`);
})
